"""
KINECT FLAME EFFECT — TouchDesigner Setup Script
=================================================
Colle ce script dans une DAT Text, puis exécute-le via
le menu clic-droit > "Run Script" ou depuis une Script DAT.

Testé avec :
  - TouchDesigner 2023.x / 2024.x
  - Kinect Azure (Microsoft Azure Kinect DK)
  - Windows 10/11 (requis pour le driver Kinect Azure)

Structure du réseau créé :
  /project1/
    kinect_flame/
      ├── kinectazure1        (Kinect Azure TOP — depth map)
      ├── kinectazure_body1   (Kinect Azure CHOP — skeleton)
      ├── threshold1          (seuil sur depth)
      ├── edgedetect1         (silhouette)
      ├── blur_silhouette1    (adoucissement bords)
      ├── glsl_flame1         (GLSL compute — particules feu)
      ├── feedback1           (traînée temporelle)
      ├── blur_heat1          (chaleur / distorsion)
      ├── displace1           (turbulence)
      ├── luma_key1           (masque feu sur silhouette)
      ├── composite1          (assemblage final)
      ├── out1                (sortie)
      └── ctrl_panel          (paramètres de contrôle)
"""

import td

ROOT = "/project1"

def make_comp(name):
    """Crée ou récupère un base COMP."""
    existing = op(f"{ROOT}/{name}")
    if existing:
        existing.destroy()
    base = op(ROOT).create(baseCOMP, name)
    base.nodeX = 0
    base.nodeY = 0
    return base

def setup_kinect_flame():
    parent = make_comp("kinect_flame")
    p = parent  # alias

    x_cursor = 0
    Y_TOP = 200    # rangée TOPs
    Y_CHOP = -100  # rangée CHOPs

    # ─────────────────────────────────────────
    # 1. KINECT AZURE — Depth Map (TOP)
    # ─────────────────────────────────────────
    kinect_top = p.create(kinectazureTOP, "kinectazure1")
    kinect_top.nodeX = x_cursor
    kinect_top.nodeY = Y_TOP
    kinect_top.par.source = "Depth"          # source = Depth image
    kinect_top.par.depthrange = 0            # Near range (0.5m – 3.5m)
    kinect_top.par.active = True

    # ─────────────────────────────────────────
    # 2. KINECT AZURE — Body Tracking (CHOP)
    # ─────────────────────────────────────────
    kinect_chop = p.create(kinectazureCHOP, "kinectazure_body1")
    kinect_chop.nodeX = x_cursor
    kinect_chop.nodeY = Y_CHOP
    kinect_chop.par.active = True
    kinect_chop.par.bodytracking = True

    x_cursor += 200

    # ─────────────────────────────────────────
    # 3. THRESHOLD — Isole la silhouette
    # ─────────────────────────────────────────
    threshold = p.create(thresholdTOP, "threshold1")
    threshold.nodeX = x_cursor
    threshold.nodeY = Y_TOP
    threshold.inputConnectors[0].connect(kinect_top)
    threshold.par.threshold = 0.85   # Ajuster selon la distance
    threshold.par.smoothstep = True

    x_cursor += 200

    # ─────────────────────────────────────────
    # 4. EDGE DETECT — Contour de la silhouette
    # ─────────────────────────────────────────
    edge = p.create(edgeTOP, "edgedetect1")
    edge.nodeX = x_cursor
    edge.nodeY = Y_TOP
    edge.inputConnectors[0].connect(threshold)
    edge.par.edgewidth = 2.0
    edge.par.edgecolor = (1, 0.4, 0.05, 1)  # orange

    x_cursor += 200

    # ─────────────────────────────────────────
    # 5. BLUR silhouette — Adoucir les bords
    # ─────────────────────────────────────────
    blur_sil = p.create(blurTOP, "blur_silhouette1")
    blur_sil.nodeX = x_cursor
    blur_sil.nodeY = Y_TOP
    blur_sil.inputConnectors[0].connect(edge)
    blur_sil.par.size = (4, 4)

    x_cursor += 200

    # ─────────────────────────────────────────
    # 6. GLSL TOP — Simulation de flamme GPU
    # ─────────────────────────────────────────
    glsl = p.create(glslTOP, "glsl_flame1")
    glsl.nodeX = x_cursor
    glsl.nodeY = Y_TOP
    glsl.inputConnectors[0].connect(blur_sil)

    # Shader GLSL injecté directement
    glsl_dat = p.create(textDAT, "glsl_flame_shader")
    glsl_dat.nodeX = x_cursor
    glsl_dat.nodeY = Y_TOP - 200
    glsl_dat.text = FLAME_GLSL_SHADER
    glsl.par.glsl = glsl_dat.path

    # Uniforms contrôlables
    glsl.par.uniform0name  = "uTime"
    glsl.par.uniform0value = "absTime.seconds"
    glsl.par.uniform1name  = "uIntensity"
    glsl.par.uniform1value = 1.2
    glsl.par.uniform2name  = "uSpeed"
    glsl.par.uniform2value = 2.5
    glsl.par.uniform3name  = "uScale"
    glsl.par.uniform3value = 4.0

    x_cursor += 200

    # ─────────────────────────────────────────
    # 7. FEEDBACK — Traînée temporelle (persistance)
    # ─────────────────────────────────────────
    feedback = p.create(feedbackTOP, "feedback1")
    feedback.nodeX = x_cursor
    feedback.nodeY = Y_TOP
    feedback.inputConnectors[0].connect(glsl)
    feedback.par.top = glsl.path   # boucle sur lui-même
    feedback.par.opacity = 0.88    # persistance (0=court, 1=infini)

    x_cursor += 200

    # ─────────────────────────────────────────
    # 8. BLUR chaleur — Diffusion de la flamme
    # ─────────────────────────────────────────
    blur_heat = p.create(blurTOP, "blur_heat1")
    blur_heat.nodeX = x_cursor
    blur_heat.nodeY = Y_TOP
    blur_heat.inputConnectors[0].connect(feedback)
    blur_heat.par.size = (3, 6)    # plus flou verticalement = montée
    blur_heat.par.blurtype = "Gaussian"

    x_cursor += 200

    # ─────────────────────────────────────────
    # 9. DISPLACE — Turbulence de la chaleur
    # ─────────────────────────────────────────
    displace = p.create(displaceTOP, "displace1")
    displace.nodeX = x_cursor
    displace.nodeY = Y_TOP
    displace.inputConnectors[0].connect(blur_heat)
    displace.par.scale = (0.015, 0.03)   # déplacement horizontal/vertical

    # Noise TOP pour la turbulence
    noise_disp = p.create(noiseTOP, "noise_displace1")
    noise_disp.nodeX = x_cursor
    noise_disp.nodeY = Y_TOP + 200
    noise_disp.par.monochrome = False
    noise_disp.par.period = 0.15
    noise_disp.par.harmonics = 4
    # Animer le noise pour la montée des flammes
    noise_disp.par.translatey = "absTime.seconds * 0.4"
    displace.inputConnectors[1].connect(noise_disp)

    x_cursor += 200

    # ─────────────────────────────────────────
    # 10. LUT — Palette de couleurs feu
    # ─────────────────────────────────────────
    lut = p.create(lut1TOP, "lut_fire1")
    lut.nodeX = x_cursor
    lut.nodeY = Y_TOP
    lut.inputConnectors[0].connect(displace)
    # Palette feu : noir → rouge → orange → jaune → blanc
    lut.par.luttype = "1D"
    lut.par.colorr = "(0, 0, 0, 1), (0.6, 0, 0, 1), (1, 0.3, 0, 1), (1, 0.8, 0.1, 1), (1, 1, 0.9, 1)"
    lut.par.colorg = "(0, 0, 0, 1), (0.0, 0, 0, 1), (0.2, 0, 0, 1), (0.7, 0.5, 0, 1), (1, 1, 0.9, 1)"
    lut.par.colorb = "(0, 0, 0, 1), (0.0, 0, 0, 1), (0.0, 0, 0, 1), (0.0, 0.0, 0, 1), (1, 1, 0.9, 1)"

    x_cursor += 200

    # ─────────────────────────────────────────
    # 11. COMPOSITE — Fond noir + flammes
    # ─────────────────────────────────────────
    bg = p.create(constantTOP, "background1")
    bg.nodeX = x_cursor - 400
    bg.nodeY = Y_TOP + 300
    bg.par.color = (0.02, 0.02, 0.05, 1)   # quasi-noir bleuté

    comp = p.create(compositeTOP, "composite1")
    comp.nodeX = x_cursor
    comp.nodeY = Y_TOP
    comp.inputConnectors[0].connect(bg)
    comp.inputConnectors[1].connect(lut)
    comp.par.operand = "Add"

    x_cursor += 200

    # ─────────────────────────────────────────
    # 12. OUT — Sortie finale
    # ─────────────────────────────────────────
    out = p.create(outTOP, "out1")
    out.nodeX = x_cursor
    out.nodeY = Y_TOP
    out.inputConnectors[0].connect(comp)

    # ─────────────────────────────────────────
    # 13. PANEL DE CONTRÔLE (paramètres live)
    # ─────────────────────────────────────────
    ctrl = p.create(containerCOMP, "ctrl_panel")
    ctrl.nodeX = 0
    ctrl.nodeY = -300

    print("✅ Réseau kinect_flame créé avec succès !")
    print(f"   Chemin : {parent.path}")
    print("   Prochaine étape : connecter la Kinect Azure et ajuster le seuil (threshold1).")

# ─────────────────────────────────────────────────────────────────────────────
# SHADER GLSL — Génération de flamme procédurale
# Basé sur une technique de bruit Simplex + montée verticale
# ─────────────────────────────────────────────────────────────────────────────

FLAME_GLSL_SHADER = """
// Kinect Flame Effect — GLSL Fragment Shader
// Input 0 : silhouette (masque blanc/noir)

uniform float uTime;
uniform float uIntensity;
uniform float uSpeed;
uniform float uScale;

out vec4 fragColor;

// Hash / bruit pseudo-aléatoire
vec2 hash2(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)),
             dot(p, vec2(269.5, 183.3)));
    return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
}

// Gradient noise 2D
float gnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(dot(hash2(i + vec2(0,0)), f - vec2(0,0)),
                   dot(hash2(i + vec2(1,0)), f - vec2(1,0)), u.x),
               mix(dot(hash2(i + vec2(0,1)), f - vec2(0,1)),
                   dot(hash2(i + vec2(1,1)), f - vec2(1,1)), u.x), u.y);
}

// FBM — Fractal Brownian Motion (couches de bruit)
float fbm(vec2 p) {
    float v = 0.0;
    float amp = 0.5;
    float freq = 1.0;
    for (int i = 0; i < 5; i++) {
        v += amp * gnoise(p * freq);
        freq *= 2.1;
        amp *= 0.5;
    }
    return v;
}

void main() {
    vec2 uv = vUV.st;

    // Lire la silhouette (masque)
    vec4 mask = texture(sTD2DInputs[0], uv);
    float presence = mask.r;  // 1 = corps présent, 0 = fond

    if (presence < 0.05) {
        fragColor = vec4(0.0);
        return;
    }

    // Coordonnées de la flamme
    vec2 flameUV = uv * uScale;

    // Montée temporelle du bruit (flamme qui monte)
    float t = uTime * uSpeed;

    // Distorsion turbulente
    float noise1 = fbm(flameUV + vec2(0.0, -t * 0.5));
    float noise2 = fbm(flameUV * 1.3 + vec2(noise1 * 0.5, -t * 0.7));

    // Gradient vertical : la flamme s'éteint vers le haut
    float verticalFade = pow(1.0 - uv.y, 1.5);

    // Intensité de flamme combinée
    float flame = noise2 * verticalFade * uIntensity * presence;
    flame = clamp(flame, 0.0, 1.0);

    // Palette feu procedurale (sera affinée par le LUT en aval)
    vec3 color = vec3(0.0);
    color = mix(color, vec3(0.8, 0.1, 0.0), smoothstep(0.0, 0.3, flame));  // rouge
    color = mix(color, vec3(1.0, 0.5, 0.0), smoothstep(0.3, 0.6, flame));  // orange
    color = mix(color, vec3(1.0, 0.9, 0.2), smoothstep(0.6, 0.85, flame)); // jaune
    color = mix(color, vec3(1.0, 1.0, 0.95), smoothstep(0.85, 1.0, flame)); // blanc chaud

    fragColor = vec4(color, flame);
}
"""

# ─────────────────────────────────────────────────────────────────────────────
# LANCEMENT
# ─────────────────────────────────────────────────────────────────────────────
setup_kinect_flame()
