# 🔥 Kinect Flame Effect — TouchDesigner
## Guide d'installation & utilisation

---

## Prérequis matériel & logiciel

| Élément | Requis |
|---|---|
| Kinect | **Azure Kinect DK** (recommandé) ou Kinect v2 |
| OS | Windows 10 / 11 (les drivers Kinect ne fonctionnent pas sur macOS/Linux) |
| TouchDesigner | 2023.11760 ou plus récent |
| GPU | Nvidia ou AMD avec support OpenGL 4.5+ (pour le shader GLSL) |

### Drivers à installer avant tout
1. **Azure Kinect SDK** (si tu utilises la Kinect Azure)  
   → https://github.com/microsoft/Azure-Kinect-Sensor-SDK/releases  
   Télécharge `Azure Kinect SDK x.x.x.exe`

2. **Azure Kinect Body Tracking SDK** (pour la détection de silhouette)  
   → https://learn.microsoft.com/en-us/azure/kinect-dk/body-sdk-download

3. Dans TouchDesigner : s'assurer que le plugin `Kinect Azure` est actif  
   (`Edit > Preferences > DATs > KinectAzure`)

---

## Installation du projet

### Étape 1 — Ouvrir TouchDesigner
Lance un nouveau projet vide (`.toe`).

### Étape 2 — Coller le script de setup
1. Dans le réseau, crée une **Text DAT** (`Tab → Text`)
2. Colle le contenu de `setup_network.py` dans cette DAT
3. Clic-droit sur la DAT → **"Run Script"**

Le réseau se construira automatiquement dans `/project1/kinect_flame/`.

---

## Structure du réseau (automatiquement créée)

```
[kinectazure1 TOP]          ← depth map de la Kinect
        │
[threshold1]                ← isole la silhouette par seuil de profondeur
        │
[edgedetect1]               ← contour du corps
        │
[blur_silhouette1]          ← adoucit les bords
        │
[glsl_flame1] ←─── [glsl_flame_shader DAT]
        │           (shader GLSL procédural)
        │
[feedback1]                 ← traînée temporelle (persistence)
        │
[blur_heat1]                ← diffusion verticale (chaleur qui monte)
        │
[displace1] ←─── [noise_displace1]    ← turbulence de la chaleur
        │
[lut_fire1]                 ← palette de couleurs feu
        │
[composite1] ←─── [background1]       ← fond sombre
        │
[out1]                      ← sortie finale (connecter à un Window COMP)
```

---

## Réglages clés à ajuster

### `threshold1` — Seuil de détection
- **`Threshold`** : entre `0.7` et `0.95` selon la distance à la Kinect
- Si la silhouette est incomplète → baisser le seuil
- Si du fond apparaît → monter le seuil

### `glsl_flame1` — Paramètres de flamme (uniforms)
| Paramètre | Valeur par défaut | Effet |
|---|---|---|
| `uIntensity` | `1.2` | Intensité globale de la flamme |
| `uSpeed` | `2.5` | Vitesse d'animation |
| `uScale` | `4.0` | Taille des turbulences |

### `feedback1` — Traînée
- **`Opacity`** : `0.88` = traînée longue, `0.5` = courte, `0.99` = quasi-permanente

### `blur_heat1` — Montée des flammes
- `Size Y` plus grand que `Size X` = flamme qui monte
- Valeurs recommandées : X=`2`, Y=`8`

---

## Adapter pour Kinect v2 (ancienne génération)

Si tu utilises une **Kinect v2** (Xbox One) plutôt que l'Azure :

1. Remplace `kinectazureTOP` par **`kinect2TOP`** dans le script
2. Change `par.source` en `"Depth"` (identique)
3. Remplace `kinectazureCHOP` par **`kinect2CHOP`**
4. La détection squelette se fait via `par.skeleton = True`

> ⚠️ La Kinect v2 nécessite aussi son propre driver :  
> https://www.microsoft.com/en-us/download/details.aspx?id=44561

---

## Affichage plein écran

1. Crée un **Window COMP** (`Tab → Window`)
2. Dans ses paramètres : `TOP = /project1/kinect_flame/out1`
3. Clic sur `Open` pour ouvrir la fenêtre de sortie
4. `Alt+Enter` pour basculer en plein écran

---

## Aller plus loin

### Ajouter des particules physiques (SOP)
- Remplacer ou compléter le GLSL par un **Particle SOP** alimenté par les positions joints de la Kinect CHOP
- Les joints du squelette (`spine`, `shoulder`, `wrist`) peuvent être utilisés comme émetteurs de particules

### Mapping sur un corps stylisé
- Utiliser un **Ramp TOP** + **Composite** pour ajouter une couche de corps visible (semi-transparent)

### Audio-réactivité
- Connecter un **Audio Spectrum CHOP** à `uIntensity` pour que la flamme pulse avec la musique

---

## Dépannage

| Problème | Solution |
|---|---|
| Kinect non détectée | Vérifier USB 3.0, réinstaller le SDK Azure Kinect |
| Silhouette inversée | Activer `Flip X` dans `kinectazure1` |
| Shader GLSL ne compile pas | Vérifier que la DAT `glsl_flame_shader` est bien liée |
| Flamme trop faible | Augmenter `uIntensity` et baisser `feedback.opacity` |
| Lag important | Réduire la résolution dans `kinectazure1` (640×576 → 320×288) |
